#include "pch.h"
#include <iostream>
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include <time.h>

int dizi[1001], dizi2[1001]; int mid; int c[1000];
int argc; char** argv; int argc2; char** argv2;
int a[1000], b[1000], i, d; int thread; int drm;

double rastMPItime; double rastOPENMPtime;


void mergeSort(int *a, int *b, int l, int r) {

	int m;

	if (l < r) {

		m = (l + r) / 2;

		mergeSort(a, b, l, m);
		mergeSort(a, b, (m + 1), r);
		int h, i, j, k;
		h = l;
		i = l;
		j = m + 1;

		while ((h <= m) && (j <= r)) {

			if (a[h] <= a[j]) {

				b[i] = a[h];
				h++;

			}

			else {

				b[i] = a[j];
				j++;

			}

			i++;

		}

		if (m < h) {

			for (k = j; k <= r; k++) {

				b[i] = a[k];
				i++;

			}

		}

		else {

			for (k = h; k <= m; k++) {

				b[i] = a[k];
				i++;

			}

		}

		for (k = l; k <= r; k++) {

			a[k] = b[k];

		}

	}

}

//OPENMPI
void merge_sortOPENMPI(int i, int j, int a[], int b[],int k,int drm) {
	double stime = omp_get_wtime();

	if (j <= i) {
		return;    
	}
	int mid = (i + j) / 2;

#pragma omp parallel sections num_threads(k)
	{

#pragma omp section
		{

			mergeSort(a, b, i, mid);   		}

#pragma omp section
		{
			mergeSort(a, b, mid + 1, j);
		}
	}

	printf("This is the sorted array: ");
	for (int c = 0; c < 1000; c++) {

		printf("%d )  %d \n",c+1, a[c]);

	}	double etime = omp_get_wtime() - stime;
	printf("\nDurum %d Threads %d  :\n ",drm,k);
	printf("\n Rastgele Sayi MPI toplam sure : %4.3f  ms\n", (rastMPItime * 1000));
	printf("\n Merge Sort OpenMP toplam sure : %4.3f  ms\n", (etime * 1000));

}
void rastgeleOPENMPI(int k,int drmm)
{
	srand(time(NULL));
	drm = drmm; thread = k;
	double stime = omp_get_wtime();

	int n = 1000;

	int a[1000], aux[1000], i, d, swap;

#pragma omp parallel num_threads(k)
	{

#pragma omp for 
		for (int i = 0; i < 1000; i++)
		{		

			dizi[i] = rand() % 1001;	

			//a[i] = dizi[i];
		}
		;

	}
	rastOPENMPtime = omp_get_wtime() - stime;
	//printf("\n Rastgele sayi bulma OpenMP toplam sure : %4.3f  ms\n", (rastOPENMPtime * 1000));

}
//MPI
void merge_sortMPI(int argc2, char** argv2) {
	
	srand(time(NULL));

	int rank;
	int sizeP;

	MPI_Init(&argc2, &argv2); double start = MPI_Wtime();
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &sizeP);

	int size = 1000 / sizeP;
	int *dizi3 = (int*)malloc(size * sizeof(int));
	MPI_Scatter(dizi, size, MPI_INT, dizi3, size, MPI_INT, 0, MPI_COMM_WORLD);

	int *dizi4 = (int*)malloc(size * sizeof(int));
	mergeSort(dizi3, dizi4, 0, (size - 1));

	int *sirali = NULL;
	if (rank == 0) {

		sirali = (int*)malloc(1000 * sizeof(int));

	}

	MPI_Gather(dizi3, size, MPI_INT, sirali, size, MPI_INT, 0, MPI_COMM_WORLD);

	if (rank == 0) {

		int *dizi5 = (int*)malloc(1000 * sizeof(int));
		mergeSort(sirali, dizi5, 0, (1000 - 1));

		printf("This is the sorted array: ");
		for (int c = 0; c < 1000; c++) {

			printf("%d )  %d \n",c+1, sirali[c]);

		}

		printf("\n");
		printf("\n");

	}


	MPI_Barrier(MPI_COMM_WORLD); 
	double end =MPI_Wtime()-start;
	MPI_Finalize();
	printf("\nDurum %d Threads %d :\n ", drm, thread);
	printf("\n Rastgele sayi bulma OpenMP toplam sure : %4.3f  ms\n", (rastOPENMPtime * 1000));
	printf("\n Merge Sort MPI toplam sure : %4.3f  ms\n", (end * 1000));

}
void rastgeleMPI(int argc, char** argv) {
	int rank, size;

	MPI_Init(&argc, &argv);	double start = MPI_Wtime();

	int n = 1000;

	int a[1000], aux[1000], i, d, swap;


	MPI_Comm_rank(MPI_COMM_WORLD, &size);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	// Get the name of the processor


	for (int i = 0; i < 1000; i++)
	{

		//srand(time(NULL));
		dizi[i] = rand() % 1001;
		//printf("%d. )  %d     %d\n", i, dizi[i], rank);

	}


	rastMPItime = MPI_Wtime() - start;
	MPI_Finalize();
	//printf("\n Rastgele Sayi MPI toplam sure : %4.3f  ms\n", (rastMPItime *1000));


}



void durum2_thread4() {

	rastgeleOPENMPI(4,2);
    merge_sortMPI(argc, argv);
}
void durum1_thread4() {

	rastgeleMPI(argc, argv);
	merge_sortOPENMPI(0,1000,dizi,b,4,1);

}

void durum2_thread8() {

	rastgeleOPENMPI(8,2);
	merge_sortMPI(argc, argv);
}
void durum1_thread8() {

	rastgeleMPI(argc, argv);
	merge_sortOPENMPI(0, 1000, dizi, b, 8,1);

}
int main() {
	
	//	durum1_thread4();
	 
		durum1_thread8();
 
		//durum2_thread4();
 
		//	durum2_thread8();
	 

}



//mpiexec -n 4 -genv OMP_NUM_THREADS 4 GUNCEL

//	
//	int n=0;
//#pragma omp parallel num_threads(4) 
//	{
//
//#pragma omp for 
//		for (int i = 0; i < 1000; i++)
//		{
//			dizi[i] = rand() % 101;
//			//int tid = omp_get_thread_num();
//		//	printf("%d )%d    thread: %d   \n ", i,dizi[i], tid);
//		}
//		;
//	
//	}
//	merge_sort(0, 999, dizi,dizi2);
	/*
printf("\n______________________________________________________________________________________________________________________");

#pragma omp parallel num_threads(8)
	{

#pragma omp for
		for (int i = 0; i < 1000; i++)
		{
			dizi2[i] = rand() % 101;
			int tid2 = omp_get_thread_num();
			printf("%d )%d    thread: %d   \n ", i, dizi2[i], tid2);
		}
		;

	}*/
