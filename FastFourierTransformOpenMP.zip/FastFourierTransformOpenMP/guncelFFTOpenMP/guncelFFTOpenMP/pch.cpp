﻿// pch.cpp: Önceden derlenen üst bilgiye karşılık gelen kaynak dosya, tamamlamanın başarılı olması için gerekli

#include "pch.h"

// Bu dosyayı genel anlamda yoksayın, ancak önceden derlenmiş üst bilgiler kullanıyorsanız kolayca erişebileceğiniz bir yerde tutun.
