// guncelOpenMP.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>  /
#include <dos.h>
#include <omp.h>

char buffer[10], buffer2[10];
char *record, *line, *record2, *line2;
int i = 0, k = 0;
int mat[1001], mat2[1001];
float a=0;
float SSortalama = 0;

int dosya1() {

	FILE *fstream = fopen("C:\\Users\\Lenovo\\source\\repos\\guncelOpenMP\\dosya1.csv", "r");

	if (fstream == NULL) {
		printf("\n file opening failed ");
		return -1;
	}
	

	while ((line = fgets(buffer, sizeof(buffer), fstream)) != NULL)
	{
		record = strtok(line, ";");
		while (record != NULL)
		{

			mat[i] = atoi(record);
			record = strtok(NULL, ";");
		}
		++i;
	}
	fclose(fstream);

}
int dosya2() {


	FILE *fstream2 = fopen("C:\\Users\\Lenovo\\source\\repos\\guncelOpenMP\\dosya2.csv", "r");
	if (fstream2 == NULL) {
		printf("\n file opening failed ");
		return -1;
	}
	while ((line2 = fgets(buffer2, sizeof(buffer2), fstream2)) != NULL)
	{
		record2 = strtok(line2, ";");
		while (record2 != NULL)
		{
			
			mat2[k]= atoi(record2);
			record2 = strtok(NULL, ";");
		}
		++k;
	}	
	fclose(fstream2);
}

int standart_sapma(int liste[]) {
		int veri_sayisi = 0;
		int ortalama = 0;
		float fark_karesi = 0;
		int n = 0; int liste_toplami=0;
		float genel_toplam=0;
#pragma omp parallel 
	{

#pragma omp for reduction(+: liste_toplami)
		for (veri_sayisi = 0; veri_sayisi < 1000; veri_sayisi++)
		{
			liste_toplami += liste[veri_sayisi];
		}


		;
		ortalama = liste_toplami / (1000);
#pragma omp barrier

#pragma omp for reduction(+: genel_toplam)
		for (n = 0; n < 1000; n++)
		{
			genel_toplam += pow(liste[n] - ortalama, 2);
		}


		;
	}

	genel_toplam = sqrt(genel_toplam / (999));
	a = genel_toplam;
	printf("%4.3f", genel_toplam);
	return 0;
}



int main()
{
	
	float d1, d2;
	int myid, myid2;
	double stime=0, etime=0;
	stime = omp_get_wtime();
	#pragma omp parallel 
	{
		#pragma omp single
		dosya1();
		#pragma omp single
		dosya2();

		#pragma omp single
		{printf("dosya1 standart sapma: ");
		standart_sapma(mat);
		d1 = a;
		}
		#pragma omp barrier

		#pragma omp single
		{
		printf("\n\ndosya2 standart sapma: ");
		standart_sapma(mat2);
		d2 = a;
		}

		
	}


	SSortalama = (d1 + d2) / 2;
	printf("\n\nortalama: %4.3f", SSortalama);
	printf("\n");



	etime = omp_get_wtime() - stime;
	printf("\ntoplam sure : %4.3f  ms\n", (etime * 1000));
	return 0;
}
 