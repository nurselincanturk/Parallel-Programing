

#include "pch.h"
#include <iostream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <omp.h>


#define MAX 1001
#define LINES 81
char dosyaarr[5000][300];

DIR * dir;
struct dirent *de;
struct dirent *de2;
char txtad[1000][100];
char str2[300];

char str[300];
int dosya() { //Klas�rden okuyaca��m�z dosyalar�n isimlerini al�yoruz ve bunu bi diziye aktar�yoruz.
	int i = 0;
	dir = opendir("C:\\Users\\Nurselin\\source\\repos\\guncelDonemProje\\ozet\\"); /*your directory*/
	while (dir)
	{
		de = readdir(dir);

		if (!de) break;
		char *string = de->d_name;
		//printf(string);
		for (int l = 0; l < 50; l++)
		{
			txtad[i][l] = string[l];
		}
		i++;

	}
	closedir(dir);
	return 0;
}
int main()
{
	dosya();
	
	int n = 1, i = 0;
	char arr[5000][50];
	char arr2[5000][50];
	int benzerlik = 0;
	int benzOran[500];
	strcpy(str, "C:\\Users\\Nurselin\\source\\repos\\guncelDonemProje\\ozet\\");
	strcpy(str2, "C:\\Users\\Nurselin\\source\\repos\\guncelDonemProje\\ozet\\");
	
//	
	FILE *ptr,*ptr2;
#pragma omp parallel									//burada paralel kulland�m buradan da bi hata al�yorum ama i�erideki d�ng� ile olan hatay� ��zemedi�im i�in anlayamad�m.
	{

#pragma omp for 
		for (int k = 2; k < 600; k++)
		{

			for (int j = 2; j < 600; j++)
			{											//iki dosyay� okuyarak i�indeki kelimeleri kar��la�t�r�yor ve benzerllikleri buluyoruz.
														//for d�ng�s�ne al�yoruz t�m dosyalar� okuyabilmek i�in fakat bu noktada bi hata al�yorum d�ng�ye girdikten bir s�re sonra program hata veriyor.
														//normal iki dosya aras�nda hata al�yorum ��nk� benzer kelime say�s� bulunuyor.

				strcat(str, txtad[k]);
				ptr = fopen(str, "r");

				strcat(str2, txtad[j]);


				ptr2 = fopen(str2, "r");

				{
					#pragma omp critical				//Critical kulland�m ��nk� diziye s�rayla kelimeleri atabilmesi i�in
					while (n > 0)
					{
						n = fscanf(ptr, "%s", arr[i]);
						n = fscanf(ptr2, "%s", arr2[i]);

						i++;
					}
					n = i;
				}
				for (int a = 0; a < 3000; a++) 
				{
					for (int b = 0; b < 3000; b++)
					{
						if (strcmp(arr[a], arr2[b]) == 0) {
							benzerlik++;
						}
					}

				}
				benzOran[k] = benzerlik;

			}
		}}
#pragma omp parallel 
	{

#pragma omp for 
		for (int i = 0; i < 1000; i++)
		{
			printf("benzerlik = %d\n", benzOran[0]);

		}
		
	}
	return 0;
}
